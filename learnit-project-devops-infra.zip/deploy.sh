#!/bin/bash
echo "Terraform apply"

terraform apply -auto-approve

echo "Ansible playbook"

cd ansible

ansible-playbook \
    --vault-password-file ".vault_pass" \
    playbook.yml

echo "Public IP addresses"

awk '
/^\[/ {
    gsub(/\[/,"")
    gsub(/\]/,"")
    group=$0
    next
}
/^$/ {next}
{
    printf "%-18s %s\n", group":", $1
}
' inventory.ini